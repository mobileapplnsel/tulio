<?php

namespace Livewire\Exceptions;

trait BypassViewHandler
{
    //
}
